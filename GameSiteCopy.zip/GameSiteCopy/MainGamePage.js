function storage(){
    if (typeof(Storage) !== "undefined") {
        if (localStorage.setData) {
          localStorage.setData = Number(localStorage.setData)+1;
        } else {
          localStorage.setData;
        } 
    }
}
/*drag and drop*/ 
    
    function allowDrop(ev) {
        ev.preventDefault();
    }
    function dragStart(ev) {
        ev.dataTransfer.setData("text", ev.target.id);
    }
        function dragDrop(ev) {
        ev.preventDefault();
        var data = ev.dataTransfer.getData("text");
        ev.target.appendChild(document.getElementById(data));
    }
    
    
    /* LogIn pop up */
    function openForm() {
        document.getElementById("myForm").style.display = "block";
      }
      
      function closeForm() {
        document.getElementById("myForm").style.display = "none";
      }
