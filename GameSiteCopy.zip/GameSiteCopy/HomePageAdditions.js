//Gonna add shapes to the background and a few interactions
window.onload= function ()
{
    ;

};